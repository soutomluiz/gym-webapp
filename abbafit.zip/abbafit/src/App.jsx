import { useState } from 'react'
import { AppProvider, useApp } from './store/AppContext'
import Home from './pages/Home'
import Programs from './pages/Programs'
import Workout from './pages/Workout'
import Reports from './pages/Reports'
import Measurements from './pages/Measurements'
import { Home as HomeIcon, Dumbbell, BarChart2, Ruler, Play } from 'lucide-react'
import './index.css'

function Inner() {
  const [page, setPage] = useState('home')
  const [programFocus, setProgramFocus] = useState(null)
  const { activeSession } = useApp()

  function navigate(p, id) {
    setPage(p)
    if (id) setProgramFocus(id)
  }

  return (
    <div className="app">
      <main style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column' }}>
        {page === 'home' && <Home onNavigate={navigate} />}
        {page === 'programs' && <Programs onNavigate={navigate} focusId={programFocus} setFocusId={setProgramFocus} />}
        {page === 'workout' && <Workout onNavigate={navigate} />}
        {page === 'reports' && <Reports />}
        {page === 'measurements' && <Measurements />}
      </main>

      <nav className="bottom-nav">
        <button className={`nav-item ${page === 'home' ? 'active' : ''}`} onClick={() => setPage('home')}>
          <HomeIcon />
          <span>Home</span>
        </button>
        <button className={`nav-item ${page === 'programs' ? 'active' : ''}`} onClick={() => setPage('programs')}>
          <Dumbbell />
          <span>Programas</span>
        </button>
        {activeSession && (
          <button className={`nav-item ${page === 'workout' ? 'active' : ''}`} onClick={() => setPage('workout')} style={{ color: 'var(--accent)' }}>
            <Play style={{ fill: 'var(--accent)' }}/>
            <span style={{ color: 'var(--accent)' }}>Treino</span>
          </button>
        )}
        <button className={`nav-item ${page === 'reports' ? 'active' : ''}`} onClick={() => setPage('reports')}>
          <BarChart2 />
          <span>Relatórios</span>
        </button>
        <button className={`nav-item ${page === 'measurements' ? 'active' : ''}`} onClick={() => setPage('measurements')}>
          <Ruler />
          <span>Medidas</span>
        </button>
      </nav>
    </div>
  )
}

export default function App() {
  return (
    <AppProvider>
      <Inner />
    </AppProvider>
  )
}
