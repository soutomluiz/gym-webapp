import { useApp } from '../store/AppContext'
import { formatDate, sessionVolume, MUSCLE_COLORS } from '../utils/helpers'
import { Dumbbell, Flame, Calendar, TrendingUp, Plus } from 'lucide-react'

export default function Home({ onNavigate }) {
  const { programs, sessions, loading } = useApp()

  if (loading) return <div className="page" style={{ color: 'var(--text2)', paddingTop: 40, textAlign: 'center' }}>Carregando...</div>

  const today = new Date()
  const todayStr = today.toDateString()
  const weekAgo = Date.now() - 7 * 86400000
  const weekSessions = sessions.filter(s => s.date >= weekAgo)
  const streak = calcStreak(sessions)
  const lastSession = sessions[0]

  // muscles trained this week
  const musclesThisWeek = {}
  weekSessions.forEach(s => s.exercises?.forEach(ex => {
    if (ex.muscle) musclesThisWeek[ex.muscle] = (musclesThisWeek[ex.muscle] || 0) + 1
  }))
  const topMuscle = Object.entries(musclesThisWeek).sort((a,b)=>b[1]-a[1])[0]

  return (
    <div className="page page-enter">
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div className="label" style={{ marginBottom: 4 }}>AbbaFit</div>
        <h1 className="display" style={{ fontSize: 36, color: 'var(--text)' }}>
          {greeting()}, <span style={{ color: 'var(--accent)' }}>Washington</span>
        </h1>
        <p style={{ color: 'var(--text2)', fontSize: 14 }}>{formatDate(Date.now())}</p>
      </div>

      {/* Stats row */}
      <div className="stat-grid" style={{ marginBottom: 20 }}>
        <div className="stat-card">
          <div className="stat-value">{streak}</div>
          <div className="stat-label">Dias seguidos 🔥</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{weekSessions.length}</div>
          <div className="stat-label">Treinos essa semana</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{sessions.length}</div>
          <div className="stat-label">Total de treinos</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{topMuscle ? topMuscle[0].split(' ')[0] : '—'}</div>
          <div className="stat-label">Músculo da semana</div>
        </div>
      </div>

      {/* Programs section */}
      <div className="section-header">
        <div className="section-title">Meus Programas</div>
        <button className="btn btn-primary btn-sm" onClick={() => onNavigate('programs')}>
          <Plus size={14}/> Novo
        </button>
      </div>

      {programs.length === 0 ? (
        <div className="card" style={{ textAlign: 'center', padding: '32px 16px' }}>
          <Dumbbell size={32} style={{ color: 'var(--text3)', marginBottom: 12 }} />
          <p style={{ color: 'var(--text2)', marginBottom: 16 }}>Nenhum programa ainda</p>
          <button className="btn btn-primary" onClick={() => onNavigate('programs')}>
            Criar primeiro programa
          </button>
        </div>
      ) : (
        programs.map(prog => (
          <ProgramCard key={prog.id} program={prog} sessions={sessions} onNavigate={onNavigate} />
        ))
      )}

      {/* Last session */}
      {lastSession && (
        <>
          <div className="section-header" style={{ marginTop: 8 }}>
            <div className="section-title">Último Treino</div>
          </div>
          <div className="card">
            <div className="row-between" style={{ marginBottom: 10 }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 15 }}>{lastSession.programName} — {lastSession.dayName}</div>
                <div style={{ fontSize: 12, color: 'var(--text2)' }}>{formatDate(lastSession.date)}</div>
              </div>
              <div className="badge badge-accent">{formatDur(lastSession.duration)}min</div>
            </div>
            <div className="tags">
              {[...new Set(lastSession.exercises?.map(e => e.muscle).filter(Boolean))].map(m => (
                <span key={m} className="badge" style={{ background: `${MUSCLE_COLORS[m]}22`, color: MUSCLE_COLORS[m] || 'var(--text2)', fontSize: 11 }}>{m}</span>
              ))}
            </div>
          </div>
        </>
      )}
    </div>
  )
}

function ProgramCard({ program, sessions, onNavigate }) {
  const progSessions = sessions.filter(s => s.programId === program.id)
  const last = progSessions[0]
  const totalDays = program.weeks?.reduce((a, w) => a + (w.days?.length || 0), 0) || 0

  return (
    <div className="card" style={{ cursor: 'pointer' }} onClick={() => onNavigate('programs', program.id)}>
      <div className="row-between" style={{ marginBottom: 8 }}>
        <div>
          <div style={{ fontWeight: 600, fontSize: 16 }}>{program.name}</div>
          <div style={{ fontSize: 12, color: 'var(--text2)' }}>{program.type} · {program.weeks?.length || 0} semanas · {totalDays} dias</div>
        </div>
        <span className="badge badge-accent">{progSessions.length} treinos</span>
      </div>
      {last && <div style={{ fontSize: 12, color: 'var(--text3)' }}>Último: {formatDate(last.date)}</div>}
    </div>
  )
}

function greeting() {
  const h = new Date().getHours()
  if (h < 12) return 'Bom dia'
  if (h < 18) return 'Boa tarde'
  return 'Boa noite'
}

function calcStreak(sessions) {
  if (!sessions.length) return 0
  let streak = 0
  let day = new Date(); day.setHours(0,0,0,0)
  const days = new Set(sessions.map(s => new Date(s.date).toDateString()))
  while (days.has(day.toDateString())) {
    streak++
    day.setDate(day.getDate() - 1)
  }
  return streak
}

function formatDur(ms) {
  if (!ms) return '0'
  return Math.round(ms / 60000)
}
