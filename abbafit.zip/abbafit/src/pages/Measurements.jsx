import { useState, useMemo } from 'react'
import { useApp } from '../store/AppContext'
import { uid, formatDate } from '../utils/helpers'
import { Plus, Trash2, X, TrendingUp, TrendingDown, Minus } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts'

const FIELDS = [
  { key: 'weight', label: 'Peso', unit: 'kg', icon: '⚖️' },
  { key: 'bf', label: 'BF%', unit: '%', icon: '🔥' },
  { key: 'chest', label: 'Peito', unit: 'cm', icon: '💪' },
  { key: 'waist', label: 'Cintura', unit: 'cm', icon: '📏' },
  { key: 'hip', label: 'Quadril', unit: 'cm', icon: '📐' },
  { key: 'armL', label: 'Braço E', unit: 'cm', icon: '💪' },
  { key: 'armR', label: 'Braço D', unit: 'cm', icon: '💪' },
  { key: 'thigh', label: 'Coxa', unit: 'cm', icon: '🦵' },
  { key: 'calf', label: 'Panturrilha', unit: 'cm', icon: '🦵' },
  { key: 'shoulder', label: 'Ombros', unit: 'cm', icon: '🏋️' },
]

export default function Measurements() {
  const { measurements, saveMeasurement, deleteMeasurement } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState({})
  const [focus, setFocus] = useState('weight')

  const latest = measurements[0]
  const prev = measurements[1]

  const chartData = useMemo(() => {
    return measurements.slice(0, 20).reverse().map(m => ({
      date: new Date(m.date).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' }),
      value: m[focus]
    })).filter(d => d.value != null && d.value !== '')
  }, [measurements, focus])

  async function handleSave() {
    const entry = { id: uid(), date: Date.now(), ...form }
    await saveMeasurement(entry)
    setForm({})
    setShowForm(false)
  }

  function diff(key) {
    if (!latest || !prev) return null
    const l = parseFloat(latest[key])
    const p = parseFloat(prev[key])
    if (isNaN(l) || isNaN(p)) return null
    return +(l - p).toFixed(1)
  }

  const focusField = FIELDS.find(f => f.key === focus)

  return (
    <div className="page page-enter">
      <div className="section-header">
        <div className="section-title">Medidas</div>
        <button className="btn btn-primary btn-sm" onClick={() => setShowForm(true)}>
          <Plus size={14}/> Nova
        </button>
      </div>

      {/* Latest snapshot */}
      {latest && (
        <div className="card" style={{ marginBottom: 20 }}>
          <div className="label" style={{ marginBottom: 10 }}>Última medição — {formatDate(latest.date)}</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
            {FIELDS.filter(f => latest[f.key] != null && latest[f.key] !== '').map(f => {
              const d = diff(f.key)
              return (
                <div
                  key={f.key}
                  onClick={() => setFocus(f.key)}
                  style={{
                    padding: '10px 8px', borderRadius: 8, cursor: 'pointer', textAlign: 'center',
                    background: focus === f.key ? 'var(--accent-dim)' : 'var(--bg3)',
                    border: focus === f.key ? '1px solid var(--accent)' : '1px solid var(--border)',
                    transition: 'all 0.15s'
                  }}
                >
                  <div style={{ fontSize: 9, color: 'var(--text2)', textTransform: 'uppercase', letterSpacing: '0.06em', marginBottom: 2 }}>{f.label}</div>
                  <div style={{ fontSize: 18, fontWeight: 700, color: focus === f.key ? 'var(--accent)' : 'var(--text)', fontFamily: "'Bebas Neue', sans-serif" }}>
                    {latest[f.key]}<span style={{ fontSize: 11, fontWeight: 400, fontFamily: 'inherit' }}>{f.unit}</span>
                  </div>
                  {d !== null && (
                    <div style={{ fontSize: 10, color: d > 0 ? (f.key === 'weight' || f.key === 'bf' || f.key === 'waist' ? 'var(--red)' : 'var(--accent)') : (d < 0 ? (f.key === 'weight' || f.key === 'bf' || f.key === 'waist' ? 'var(--accent)' : 'var(--red)') : 'var(--text3)'), marginTop: 2 }}>
                      {d > 0 ? `+${d}` : d < 0 ? d : '—'}
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* Chart for selected metric */}
      {chartData.length > 1 && (
        <div className="card" style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text2)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }}>
            {focusField?.icon} {focusField?.label} ao longo do tempo
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <LineChart data={chartData} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
              <XAxis dataKey="date" tick={{ fill: '#666', fontSize: 10 }} />
              <YAxis tick={{ fill: '#666', fontSize: 10 }} domain={['auto', 'auto']} />
              <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8 }} labelStyle={{ color: '#aaa' }} itemStyle={{ color: '#c8f135' }} />
              <Line type="monotone" dataKey="value" stroke="#c8f135" strokeWidth={2} dot={{ fill: '#c8f135', r: 3 }} name={focusField?.label}/>
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {/* History */}
      <div className="section-header">
        <div className="section-title">Histórico</div>
      </div>
      {measurements.length === 0 && (
        <div className="card" style={{ textAlign: 'center', padding: '32px 16px' }}>
          <p style={{ color: 'var(--text2)', marginBottom: 16 }}>Nenhuma medição ainda</p>
          <button className="btn btn-primary" onClick={() => setShowForm(true)}>Adicionar primeira medição</button>
        </div>
      )}
      {measurements.slice(0, 10).map(m => (
        <div key={m.id} className="card card-sm" style={{ marginBottom: 8 }}>
          <div className="row-between">
            <div style={{ fontSize: 13, fontWeight: 500 }}>{formatDate(m.date)}</div>
            <button className="btn-icon" style={{ color: 'var(--red)' }} onClick={() => { if(confirm('Deletar?')) deleteMeasurement(m.id) }}>
              <Trash2 size={13}/>
            </button>
          </div>
          <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 4 }}>
            {FIELDS.filter(f => m[f.key] != null && m[f.key] !== '').map(f => `${f.label}: ${m[f.key]}${f.unit}`).join(' · ')}
          </div>
        </div>
      ))}

      {/* Add modal */}
      {showForm && (
        <div className="modal-backdrop" onClick={() => setShowForm(false)}>
          <div className="modal" onClick={e => e.stopPropagation()}>
            <div className="modal-handle"/>
            <div className="row-between" style={{ marginBottom: 20 }}>
              <h2 style={{ fontSize: 18, fontWeight: 600 }}>Nova medição</h2>
              <button className="btn-icon" onClick={() => setShowForm(false)}><X size={16}/></button>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              {FIELDS.map(f => (
                <div key={f.key} className="form-group" style={{ marginBottom: 0 }}>
                  <label>{f.icon} {f.label} ({f.unit})</label>
                  <input
                    type="number" inputMode="decimal" step="0.1"
                    placeholder="—"
                    value={form[f.key] || ''}
                    onChange={e => setForm(prev => ({ ...prev, [f.key]: e.target.value }))}
                  />
                </div>
              ))}
            </div>
            <button className="btn btn-primary btn-full" style={{ marginTop: 20 }} onClick={handleSave}>
              Salvar medição
            </button>
          </div>
        </div>
      )}
    </div>
  )
}
