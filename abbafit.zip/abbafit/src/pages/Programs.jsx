import { useState } from 'react'
import { useApp } from '../store/AppContext'
import { uid, MUSCLE_GROUPS, WORKOUT_TYPES, MUSCLE_COLORS } from '../utils/helpers'
import { Plus, Trash2, ChevronDown, ChevronRight, Edit2, Play, Upload, X, GripVertical, Clock } from 'lucide-react'

export default function Programs({ onNavigate, focusId, setFocusId }) {
  const { programs, saveProgram, deleteProgram, setActiveSession } = useApp()
  const [showForm, setShowForm] = useState(false)
  const [editProgram, setEditProgram] = useState(null)
  const [expandedProgram, setExpandedProgram] = useState(focusId || null)
  const [expandedWeek, setExpandedWeek] = useState(null)
  const [importModal, setImportModal] = useState(false)
  const [importProg, setImportProg] = useState(null)

  function startEdit(prog) {
    setEditProgram(JSON.parse(JSON.stringify(prog)))
    setShowForm(true)
  }

  function startNew() {
    setEditProgram({
      id: uid(), name: '', type: 'Hipertrofia', restSeconds: 90,
      weeks: [{ id: uid(), name: 'Semana 1', days: [] }]
    })
    setShowForm(true)
  }

  async function handleSave(prog) {
    await saveProgram(prog)
    setShowForm(false)
    setEditProgram(null)
    setExpandedProgram(prog.id)
  }

  function startWorkout(prog, week, day) {
    setActiveSession({
      id: uid(),
      programId: prog.id,
      programName: prog.name,
      weekId: week.id,
      weekName: week.name,
      dayId: day.id,
      dayName: day.name,
      restSeconds: prog.restSeconds || 90,
      date: Date.now(),
      startTime: Date.now(),
      exercises: day.exercises.map(ex => ({
        ...ex,
        sets: ex.sets.map(s => ({ ...s, done: false, actualReps: s.reps, actualWeight: s.weight }))
      }))
    })
    onNavigate('workout')
  }

  return (
    <div className="page page-enter">
      <div className="section-header">
        <div className="section-title">Programas</div>
        <div style={{ display: 'flex', gap: 8 }}>
          <button className="btn btn-ghost btn-sm" onClick={() => setImportModal(true)}>
            <Upload size={14}/> PDF
          </button>
          <button className="btn btn-primary btn-sm" onClick={startNew}>
            <Plus size={14}/> Novo
          </button>
        </div>
      </div>

      {programs.length === 0 && !showForm && (
        <div className="card" style={{ textAlign: 'center', padding: '40px 16px' }}>
          <p style={{ color: 'var(--text2)', marginBottom: 16 }}>Crie seu primeiro programa de treino</p>
          <button className="btn btn-primary" onClick={startNew}>Criar programa</button>
        </div>
      )}

      {programs.map(prog => (
        <div key={prog.id} className="card" style={{ padding: 0, overflow: 'hidden' }}>
          {/* Program header */}
          <div
            style={{ padding: '14px 16px', cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}
            onClick={() => setExpandedProgram(expandedProgram === prog.id ? null : prog.id)}
          >
            <div>
              <div style={{ fontWeight: 600, fontSize: 16 }}>{prog.name}</div>
              <div style={{ fontSize: 12, color: 'var(--text2)' }}>
                {prog.type} · {prog.weeks?.length || 0} semanas · <Clock size={11} style={{ display:'inline', verticalAlign:'middle' }}/> {prog.restSeconds || 90}s descanso
              </div>
            </div>
            <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <button className="btn-icon" onClick={e => { e.stopPropagation(); startEdit(prog) }}><Edit2 size={14}/></button>
              <button className="btn-icon" style={{ color: 'var(--red)' }} onClick={e => { e.stopPropagation(); if(confirm('Deletar programa?')) deleteProgram(prog.id) }}><Trash2 size={14}/></button>
              {expandedProgram === prog.id ? <ChevronDown size={16} style={{ color: 'var(--text2)' }}/> : <ChevronRight size={16} style={{ color: 'var(--text2)' }}/>}
            </div>
          </div>

          {expandedProgram === prog.id && (
            <div style={{ borderTop: '1px solid var(--border)' }}>
              {prog.weeks?.map(week => (
                <div key={week.id}>
                  <div
                    style={{ padding: '10px 16px', cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, background: 'var(--bg3)' }}
                    onClick={() => setExpandedWeek(expandedWeek === week.id ? null : week.id)}
                  >
                    {expandedWeek === week.id ? <ChevronDown size={14}/> : <ChevronRight size={14}/>}
                    <span style={{ fontWeight: 500, fontSize: 14 }}>{week.name}</span>
                    <span style={{ fontSize: 12, color: 'var(--text2)' }}>— {week.days?.length || 0} dias</span>
                  </div>

                  {expandedWeek === week.id && week.days?.map(day => (
                    <div key={day.id} style={{ padding: '12px 16px', borderTop: '1px solid var(--border)' }}>
                      <div className="row-between" style={{ marginBottom: 10 }}>
                        <div>
                          <div style={{ fontWeight: 500, fontSize: 14 }}>{day.name}</div>
                          <div style={{ fontSize: 12, color: 'var(--text2)' }}>{day.type}</div>
                        </div>
                        <button
                          className="btn btn-primary btn-sm"
                          onClick={() => startWorkout(prog, week, day)}
                          disabled={!day.exercises?.length}
                        >
                          <Play size={13}/> Iniciar
                        </button>
                      </div>
                      {day.exercises?.map(ex => (
                        <div key={ex.id} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6, padding: '8px 10px', background: 'var(--bg3)', borderRadius: 8 }}>
                          <div
                            style={{ width: 8, height: 8, borderRadius: '50%', background: MUSCLE_COLORS[ex.muscle] || '#555', flexShrink: 0 }}
                          />
                          <div style={{ flex: 1 }}>
                            <div style={{ fontSize: 13, fontWeight: 500 }}>{ex.name}</div>
                            <div style={{ fontSize: 11, color: 'var(--text2)' }}>
                              {ex.sets?.length || 0} séries · {ex.muscle}
                            </div>
                          </div>
                          <div style={{ fontSize: 12, color: 'var(--text3)' }}>
                            {ex.sets?.[0] ? `${ex.sets[0].reps} reps × ${ex.sets[0].weight}kg` : ''}
                          </div>
                        </div>
                      ))}
                      {!day.exercises?.length && (
                        <div style={{ fontSize: 13, color: 'var(--text3)', padding: '8px 0' }}>Sem exercícios ainda</div>
                      )}
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      {/* Program Form Modal */}
      {showForm && editProgram && (
        <ProgramFormModal
          program={editProgram}
          onSave={handleSave}
          onClose={() => { setShowForm(false); setEditProgram(null) }}
        />
      )}

      {/* PDF Import Modal */}
      {importModal && (
        <ImportModal
          onClose={() => { setImportModal(false); setImportProg(null) }}
          onImport={async (prog) => { await saveProgram(prog); setImportModal(false) }}
        />
      )}
    </div>
  )
}

// ─────────────────────────────────────────────
// Program Form Modal
// ─────────────────────────────────────────────
function ProgramFormModal({ program, onSave, onClose }) {
  const [p, setP] = useState(program)

  const up = (patch) => setP(prev => ({ ...prev, ...patch }))

  function addWeek() {
    setP(prev => ({ ...prev, weeks: [...(prev.weeks||[]), { id: uid(), name: `Semana ${(prev.weeks?.length||0)+1}`, days: [] }] }))
  }
  function removeWeek(wid) {
    setP(prev => ({ ...prev, weeks: prev.weeks.filter(w => w.id !== wid) }))
  }
  function upWeek(wid, patch) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, ...patch } : w) }))
  }
  function addDay(wid) {
    setP(prev => ({
      ...prev,
      weeks: prev.weeks.map(w => w.id === wid
        ? { ...w, days: [...(w.days||[]), { id: uid(), name: `Dia ${(w.days?.length||0)+1}`, type: 'Hipertrofia', exercises: [] }] }
        : w)
    }))
  }
  function removeDay(wid, did) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.filter(d => d.id !== did) } : w) }))
  }
  function upDay(wid, did, patch) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.map(d => d.id === did ? { ...d, ...patch } : d) } : w) }))
  }
  function addExercise(wid, did) {
    const newEx = { id: uid(), name: '', muscle: 'Peito', sets: [{ id: uid(), reps: 12, weight: 0 }] }
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.map(d => d.id === did ? { ...d, exercises: [...(d.exercises||[]), newEx] } : d) } : w) }))
  }
  function removeExercise(wid, did, eid) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.map(d => d.id === did ? { ...d, exercises: d.exercises.filter(e => e.id !== eid) } : d) } : w) }))
  }
  function upExercise(wid, did, eid, patch) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.map(d => d.id === did ? { ...d, exercises: d.exercises.map(e => e.id === eid ? { ...e, ...patch } : e) } : d) } : w) }))
  }
  function addSet(wid, did, eid) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.map(d => d.id === did ? { ...d, exercises: d.exercises.map(e => e.id === eid ? { ...e, sets: [...e.sets, { id: uid(), reps: e.sets[e.sets.length-1]?.reps||12, weight: e.sets[e.sets.length-1]?.weight||0 }] } : e) } : d) } : w) }))
  }
  function removeSet(wid, did, eid, sid) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.map(d => d.id === did ? { ...d, exercises: d.exercises.map(e => e.id === eid ? { ...e, sets: e.sets.filter(s => s.id !== sid) } : e) } : d) } : w) }))
  }
  function upSet(wid, did, eid, sid, patch) {
    setP(prev => ({ ...prev, weeks: prev.weeks.map(w => w.id === wid ? { ...w, days: w.days.map(d => d.id === did ? { ...d, exercises: d.exercises.map(e => e.id === eid ? { ...e, sets: e.sets.map(s => s.id === sid ? { ...s, ...patch } : s) } : e) } : d) } : w) }))
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-handle"/>
        <div className="row-between" style={{ marginBottom: 20 }}>
          <h2 style={{ fontSize: 18, fontWeight: 600 }}>{p.id && program.name ? 'Editar' : 'Novo'} Programa</h2>
          <button className="btn-icon" onClick={onClose}><X size={16}/></button>
        </div>

        {/* Basic info */}
        <div className="form-group">
          <label>Nome do programa</label>
          <input value={p.name} onChange={e => up({ name: e.target.value })} placeholder="Ex: PPL Hipertrofia" />
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, marginBottom: 14 }}>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label>Tipo</label>
            <select value={p.type} onChange={e => up({ type: e.target.value })}>
              {WORKOUT_TYPES.map(t => <option key={t}>{t}</option>)}
            </select>
          </div>
          <div className="form-group" style={{ marginBottom: 0 }}>
            <label>Descanso padrão (seg)</label>
            <input type="number" value={p.restSeconds || 90} onChange={e => up({ restSeconds: +e.target.value })} min={10} max={600}/>
          </div>
        </div>

        <hr className="divider"/>

        {/* Weeks */}
        {p.weeks?.map((week, wi) => (
          <div key={week.id} style={{ marginBottom: 20, background: 'var(--bg3)', borderRadius: 10, padding: 14 }}>
            <div className="row-between" style={{ marginBottom: 10 }}>
              <input
                value={week.name} onChange={e => upWeek(week.id, { name: e.target.value })}
                style={{ fontWeight: 600, fontSize: 14, padding: '6px 10px', flex: 1 }}
              />
              <button className="btn-icon" style={{ color: 'var(--red)', marginLeft: 8 }} onClick={() => removeWeek(week.id)}><Trash2 size={13}/></button>
            </div>

            {week.days?.map(day => (
              <div key={day.id} style={{ background: 'var(--bg2)', borderRadius: 8, padding: 12, marginBottom: 10 }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', gap: 8, marginBottom: 10 }}>
                  <input value={day.name} onChange={e => upDay(week.id, day.id, { name: e.target.value })} placeholder="Nome do dia" style={{ fontSize: 13 }}/>
                  <select value={day.type} onChange={e => upDay(week.id, day.id, { type: e.target.value })} style={{ fontSize: 13 }}>
                    {WORKOUT_TYPES.map(t => <option key={t}>{t}</option>)}
                  </select>
                  <button className="btn-icon" style={{ color: 'var(--red)' }} onClick={() => removeDay(week.id, day.id)}><Trash2 size={13}/></button>
                </div>

                {/* Exercises */}
                {day.exercises?.map(ex => (
                  <div key={ex.id} style={{ background: 'var(--bg3)', borderRadius: 8, padding: 10, marginBottom: 8 }}>
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr auto', gap: 8, marginBottom: 8 }}>
                      <input value={ex.name} onChange={e => upExercise(week.id, day.id, ex.id, { name: e.target.value })} placeholder="Exercício" style={{ fontSize: 13 }}/>
                      <select value={ex.muscle} onChange={e => upExercise(week.id, day.id, ex.id, { muscle: e.target.value })} style={{ fontSize: 13 }}>
                        {MUSCLE_GROUPS.map(m => <option key={m}>{m}</option>)}
                      </select>
                      <button className="btn-icon" style={{ color: 'var(--red)' }} onClick={() => removeExercise(week.id, day.id, ex.id)}><Trash2 size={12}/></button>
                    </div>
                    {/* Sets */}
                    <div style={{ display: 'grid', gridTemplateColumns: 'auto 1fr 1fr auto', gap: 6, alignItems: 'center', marginBottom: 6 }}>
                      <span style={{ fontSize: 10, color: 'var(--text3)', textAlign: 'center' }}>#</span>
                      <span style={{ fontSize: 10, color: 'var(--text3)' }}>Reps</span>
                      <span style={{ fontSize: 10, color: 'var(--text3)' }}>Kg</span>
                      <span/>
                    </div>
                    {ex.sets?.map((set, si) => (
                      <div key={set.id} style={{ display: 'grid', gridTemplateColumns: 'auto 1fr 1fr auto', gap: 6, alignItems: 'center', marginBottom: 4 }}>
                        <span style={{ fontSize: 11, color: 'var(--text2)', width: 20, textAlign: 'center' }}>{si+1}</span>
                        <input type="number" value={set.reps} onChange={e => upSet(week.id, day.id, ex.id, set.id, { reps: +e.target.value })} min={1} style={{ fontSize: 13, padding: '6px 8px' }}/>
                        <input type="number" value={set.weight} onChange={e => upSet(week.id, day.id, ex.id, set.id, { weight: +e.target.value })} min={0} step={0.5} style={{ fontSize: 13, padding: '6px 8px' }}/>
                        <button className="btn-icon" onClick={() => removeSet(week.id, day.id, ex.id, set.id)}><X size={11}/></button>
                      </div>
                    ))}
                    <button className="btn btn-ghost btn-sm" style={{ marginTop: 4, fontSize: 12 }} onClick={() => addSet(week.id, day.id, ex.id)}>
                      <Plus size={11}/> Série
                    </button>
                  </div>
                ))}
                <button className="btn btn-ghost btn-sm" style={{ width: '100%', marginTop: 4 }} onClick={() => addExercise(week.id, day.id)}>
                  <Plus size={13}/> Exercício
                </button>
              </div>
            ))}
            <button className="btn btn-ghost btn-sm" style={{ width: '100%' }} onClick={() => addDay(week.id)}>
              <Plus size={13}/> Dia de treino
            </button>
          </div>
        ))}

        <button className="btn btn-ghost btn-full" style={{ marginBottom: 16 }} onClick={addWeek}>
          <Plus size={14}/> Adicionar semana
        </button>

        <button
          className="btn btn-primary btn-full"
          onClick={() => { if(!p.name.trim()) return alert('Dê um nome ao programa'); onSave(p) }}
        >
          Salvar programa
        </button>
      </div>
    </div>
  )
}

// ─────────────────────────────────────────────
// PDF Import Modal
// ─────────────────────────────────────────────
function ImportModal({ onClose, onImport }) {
  const [status, setStatus] = useState('idle') // idle | loading | done | error
  const [result, setResult] = useState(null)
  const [apiKey, setApiKey] = useState(localStorage.getItem('anthropic_key') || '')

  async function handleFile(e) {
    const file = e.target.files[0]
    if (!file) return
    if (!apiKey.trim()) { alert('Insira sua API Key da Anthropic'); return }
    localStorage.setItem('anthropic_key', apiKey)
    setStatus('loading')
    try {
      const b64 = await toBase64(file)
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-opus-4-6',
          max_tokens: 4000,
          messages: [{
            role: 'user',
            content: [
              { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: b64 } },
              { type: 'text', text: `Analise esta ficha de treino e retorne APENAS um JSON válido (sem markdown, sem texto extra) com esta estrutura exata:
{
  "name": "nome do programa",
  "type": "tipo (Hipertrofia/Força/etc)",
  "restSeconds": 90,
  "weeks": [
    {
      "id": "w1",
      "name": "Semana 1",
      "days": [
        {
          "id": "d1",
          "name": "Dia A - Peito/Tríceps",
          "type": "Push",
          "exercises": [
            {
              "id": "e1",
              "name": "Supino Reto",
              "muscle": "Peito",
              "sets": [
                { "id": "s1", "reps": 12, "weight": 60 }
              ]
            }
          ]
        }
      ]
    }
  ]
}
Músculos válidos: Peito, Costas, Ombro, Bíceps, Tríceps, Antebraço, Core / Abdômen, Glúteo, Quadríceps, Posterior, Panturrilha, Trapézio, Deltóide posterior, Full Body.
Se não encontrar peso, use 0. Mantenha a estrutura de semanas/dias como na ficha.` }
            ]
          }]
        })
      })
      const data = await res.json()
      const text = data.content?.[0]?.text || ''
      const clean = text.replace(/```json|```/g, '').trim()
      const parsed = JSON.parse(clean)
      // inject unique ids
      parsed.id = uid()
      parsed.weeks = parsed.weeks.map((w,wi) => ({
        ...w, id: uid(),
        days: w.days.map((d,di) => ({
          ...d, id: uid(),
          exercises: d.exercises.map((e,ei) => ({
            ...e, id: uid(),
            sets: e.sets.map((s,si) => ({ ...s, id: uid() }))
          }))
        }))
      }))
      setResult(parsed)
      setStatus('done')
    } catch (err) {
      console.error(err)
      setStatus('error')
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal" onClick={e => e.stopPropagation()}>
        <div className="modal-handle"/>
        <div className="row-between" style={{ marginBottom: 20 }}>
          <h2 style={{ fontSize: 18, fontWeight: 600 }}>Importar PDF</h2>
          <button className="btn-icon" onClick={onClose}><X size={16}/></button>
        </div>

        {status === 'idle' && (
          <>
            <div className="form-group">
              <label>API Key Anthropic</label>
              <input type="password" value={apiKey} onChange={e => setApiKey(e.target.value)} placeholder="sk-ant-..." />
              <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>Salva localmente no seu dispositivo</div>
            </div>
            <div className="form-group">
              <label>Arquivo PDF da ficha</label>
              <input type="file" accept=".pdf" onChange={handleFile} style={{ fontSize: 13 }}/>
            </div>
            <p style={{ fontSize: 13, color: 'var(--text2)' }}>A IA vai ler a ficha e estruturar semanas, dias e exercícios automaticamente.</p>
          </>
        )}

        {status === 'loading' && (
          <div style={{ textAlign: 'center', padding: '32px 0' }}>
            <div style={{ fontSize: 32, marginBottom: 12 }}>⏳</div>
            <p style={{ color: 'var(--text2)' }}>Analisando sua ficha...</p>
          </div>
        )}

        {status === 'error' && (
          <div style={{ textAlign: 'center', padding: '24px 0' }}>
            <p style={{ color: 'var(--red)', marginBottom: 16 }}>Erro ao processar. Verifique a API Key e o PDF.</p>
            <button className="btn btn-ghost" onClick={() => setStatus('idle')}>Tentar novamente</button>
          </div>
        )}

        {status === 'done' && result && (
          <>
            <div style={{ background: 'var(--bg3)', borderRadius: 10, padding: 14, marginBottom: 16 }}>
              <div style={{ fontWeight: 600, marginBottom: 4 }}>{result.name}</div>
              <div style={{ fontSize: 13, color: 'var(--text2)' }}>{result.weeks?.length} semana(s) · {result.type}</div>
              {result.weeks?.map(w => (
                <div key={w.id} style={{ marginTop: 8 }}>
                  <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--accent)' }}>{w.name}</div>
                  {w.days?.map(d => (
                    <div key={d.id} style={{ fontSize: 12, color: 'var(--text2)', marginLeft: 8 }}>
                      {d.name} — {d.exercises?.length} exercícios
                    </div>
                  ))}
                </div>
              ))}
            </div>
            <button className="btn btn-primary btn-full" onClick={() => onImport(result)}>
              Importar programa
            </button>
          </>
        )}
      </div>
    </div>
  )
}

function toBase64(file) {
  return new Promise((res, rej) => {
    const r = new FileReader()
    r.onload = () => res(r.result.split(',')[1])
    r.onerror = rej
    r.readAsDataURL(file)
  })
}
