import { useState, useMemo } from 'react'
import { useApp } from '../store/AppContext'
import { monthLabel, weekLabel, volumeByMuscle, sessionVolume, MUSCLE_COLORS, formatDate, formatDuration } from '../utils/helpers'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts'

const TABS = ['Semana', 'Mês', 'Músculos', 'Tipos']

export default function Reports() {
  const { sessions, programs } = useApp()
  const [tab, setTab] = useState(0)
  const [period, setPeriod] = useState('30') // days

  const filtered = useMemo(() => {
    const cutoff = Date.now() - parseInt(period) * 86400000
    return sessions.filter(s => s.date >= cutoff)
  }, [sessions, period])

  return (
    <div className="page page-enter">
      <div className="section-header">
        <div className="section-title">Relatórios</div>
        <select value={period} onChange={e => setPeriod(e.target.value)} style={{ width: 'auto', padding: '6px 10px', fontSize: 13 }}>
          <option value="7">7 dias</option>
          <option value="30">30 dias</option>
          <option value="90">3 meses</option>
          <option value="365">1 ano</option>
        </select>
      </div>

      {/* Summary stats */}
      <div className="stat-grid" style={{ marginBottom: 20 }}>
        <div className="stat-card">
          <div className="stat-value">{filtered.length}</div>
          <div className="stat-label">Treinos</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{Math.round(filtered.reduce((a,s) => a + (s.duration||0), 0) / 60000)}</div>
          <div className="stat-label">Minutos total</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{Math.round(filtered.reduce((a,s) => a + sessionVolume(s), 0) / 1000)}k</div>
          <div className="stat-label">Volume total (kg)</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{filtered.length ? Math.round(filtered.reduce((a,s) => a + (s.duration||0), 0) / filtered.length / 60000) : 0}</div>
          <div className="stat-label">Média min/treino</div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', gap: 6, marginBottom: 20, background: 'var(--bg3)', borderRadius: 10, padding: 4 }}>
        {TABS.map((t, i) => (
          <button key={t} onClick={() => setTab(i)} style={{
            flex: 1, padding: '8px 4px', border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 500, cursor: 'pointer',
            background: tab === i ? 'var(--accent)' : 'transparent',
            color: tab === i ? '#0a0a0a' : 'var(--text2)',
            transition: 'all 0.15s'
          }}>{t}</button>
        ))}
      </div>

      {tab === 0 && <WeekChart sessions={filtered} />}
      {tab === 1 && <MonthChart sessions={filtered} />}
      {tab === 2 && <MuscleChart sessions={filtered} />}
      {tab === 3 && <TypeChart sessions={filtered} />}

      {/* Session list */}
      <div className="section-header" style={{ marginTop: 20 }}>
        <div className="section-title">Histórico</div>
      </div>
      {filtered.length === 0 && <div style={{ color: 'var(--text2)', fontSize: 14 }}>Nenhum treino neste período</div>}
      {filtered.slice(0, 20).map(s => (
        <SessionRow key={s.id} session={s} />
      ))}
    </div>
  )
}

function WeekChart({ sessions }) {
  const data = useMemo(() => {
    const map = {}
    sessions.forEach(s => {
      const k = weekLabel(s.date)
      if (!map[k]) map[k] = { week: k, treinos: 0, volume: 0 }
      map[k].treinos++
      map[k].volume += Math.round(sessionVolume(s) / 1000)
    })
    return Object.values(map).slice(-8)
  }, [sessions])

  return (
    <div>
      <ChartCard title="Treinos por semana">
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <XAxis dataKey="week" tick={{ fill: '#666', fontSize: 11 }} />
            <YAxis tick={{ fill: '#666', fontSize: 11 }} />
            <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8 }} labelStyle={{ color: '#aaa' }} itemStyle={{ color: '#c8f135' }} />
            <Bar dataKey="treinos" fill="#c8f135" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
      <ChartCard title="Volume semanal (toneladas)">
        <ResponsiveContainer width="100%" height={180}>
          <LineChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <XAxis dataKey="week" tick={{ fill: '#666', fontSize: 11 }} />
            <YAxis tick={{ fill: '#666', fontSize: 11 }} />
            <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8 }} labelStyle={{ color: '#aaa' }} itemStyle={{ color: '#4488ff' }} />
            <Line type="monotone" dataKey="volume" stroke="#4488ff" strokeWidth={2} dot={{ fill: '#4488ff', r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}

function MonthChart({ sessions }) {
  const data = useMemo(() => {
    const map = {}
    sessions.forEach(s => {
      const k = monthLabel(s.date)
      if (!map[k]) map[k] = { month: k, treinos: 0, volume: 0, duracao: 0 }
      map[k].treinos++
      map[k].volume += Math.round(sessionVolume(s) / 1000)
      map[k].duracao += Math.round((s.duration || 0) / 60000)
    })
    return Object.values(map)
  }, [sessions])

  return (
    <div>
      <ChartCard title="Treinos por mês">
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <XAxis dataKey="month" tick={{ fill: '#666', fontSize: 11 }} />
            <YAxis tick={{ fill: '#666', fontSize: 11 }} />
            <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8 }} itemStyle={{ color: '#c8f135' }} />
            <Bar dataKey="treinos" fill="#c8f135" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
      <ChartCard title="Volume mensal (toneladas)">
        <ResponsiveContainer width="100%" height={180}>
          <BarChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
            <XAxis dataKey="month" tick={{ fill: '#666', fontSize: 11 }} />
            <YAxis tick={{ fill: '#666', fontSize: 11 }} />
            <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8 }} itemStyle={{ color: '#4488ff' }} />
            <Bar dataKey="volume" fill="#4488ff" radius={[4,4,0,0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>
    </div>
  )
}

function MuscleChart({ sessions }) {
  const data = useMemo(() => {
    const vol = volumeByMuscle(sessions)
    const counts = {}
    sessions.forEach(s => s.exercises?.forEach(ex => {
      if (ex.muscle) counts[ex.muscle] = (counts[ex.muscle] || 0) + (ex.sets?.filter(s=>s.done).length || ex.sets?.length || 0)
    }))
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value, volume: Math.round((vol[name]||0) / 1000 * 10) / 10 }))
      .sort((a,b) => b.value - a.value)
  }, [sessions])

  return (
    <div>
      <ChartCard title="Séries por músculo">
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={data} layout="vertical" margin={{ top: 0, right: 20, left: 60, bottom: 0 }}>
            <XAxis type="number" tick={{ fill: '#666', fontSize: 10 }} />
            <YAxis type="category" dataKey="name" tick={{ fill: '#aaa', fontSize: 11 }} width={60}/>
            <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8 }} itemStyle={{ color: '#c8f135' }} />
            <Bar dataKey="value" radius={[0,4,4,0]}>
              {data.map((d, i) => (
                <Cell key={i} fill={MUSCLE_COLORS[d.name] || '#555'} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Volume por músculo (kg × rep)">
        {data.map(d => (
          <div key={d.name} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
            <div style={{ width: 10, height: 10, borderRadius: '50%', background: MUSCLE_COLORS[d.name] || '#555', flexShrink: 0 }}/>
            <div style={{ flex: 1, fontSize: 13 }}>{d.name}</div>
            <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--accent)' }}>{d.volume}k</div>
            <div style={{ width: 80, height: 6, background: 'var(--border)', borderRadius: 3 }}>
              <div style={{
                height: '100%', borderRadius: 3,
                background: MUSCLE_COLORS[d.name] || '#555',
                width: `${Math.min(100, (d.volume / (data[0]?.volume || 1)) * 100)}%`
              }}/>
            </div>
          </div>
        ))}
      </ChartCard>
    </div>
  )
}

function TypeChart({ sessions }) {
  const data = useMemo(() => {
    const map = {}
    sessions.forEach(s => {
      const t = s.exercises?.[0]?.type || 'Geral'
      // use program day type via dayType
      const key = s.dayType || t
      map[key] = (map[key] || 0) + 1
    })
    // from day name keywords
    const keyMap = {}
    sessions.forEach(s => {
      const name = (s.dayName || '').toLowerCase()
      let type = 'Outro'
      if (name.includes('push') || name.includes('peito') || name.includes('tricep')) type = 'Push'
      else if (name.includes('pull') || name.includes('costa') || name.includes('bicep')) type = 'Pull'
      else if (name.includes('leg') || name.includes('perna') || name.includes('quad') || name.includes('posterior')) type = 'Legs'
      else if (name.includes('upper')) type = 'Upper'
      else if (name.includes('lower')) type = 'Lower'
      else if (name.includes('full')) type = 'Full Body'
      keyMap[type] = (keyMap[type] || 0) + 1
    })
    return Object.entries(keyMap).map(([name, value]) => ({ name, value })).sort((a,b)=>b.value-a.value)
  }, [sessions])

  const COLORS = ['#c8f135', '#4488ff', '#ff8c00', '#ff4444', '#8338ec', '#3a86ff']

  return (
    <div>
      <ChartCard title="Distribuição por tipo de treino">
        {data.length > 0 ? (
          <ResponsiveContainer width="100%" height={200}>
            <PieChart>
              <Pie data={data} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${Math.round(percent*100)}%`} labelLine={false} fontSize={11}>
                {data.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8 }} />
            </PieChart>
          </ResponsiveContainer>
        ) : <div style={{ color: 'var(--text2)', fontSize: 13, padding: '20px 0' }}>Nenhum dado disponível</div>}
      </ChartCard>

      <ChartCard title="Contagem por tipo">
        {data.map((d, i) => (
          <div key={d.name} className="row-between" style={{ marginBottom: 10 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{ width: 10, height: 10, borderRadius: 2, background: COLORS[i % COLORS.length] }}/>
              <span style={{ fontSize: 14 }}>{d.name}</span>
            </div>
            <span className="badge badge-accent">{d.value}x</span>
          </div>
        ))}
      </ChartCard>
    </div>
  )
}

function ChartCard({ title, children }) {
  return (
    <div className="card" style={{ marginBottom: 14 }}>
      <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text2)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 14 }}>{title}</div>
      {children}
    </div>
  )
}

function SessionRow({ session }) {
  const muscles = [...new Set(session.exercises?.map(e => e.muscle).filter(Boolean))]
  const doneSets = session.exercises?.reduce((a, ex) => a + (ex.sets?.filter(s => s.done).length || 0), 0) || 0
  return (
    <div className="card card-sm" style={{ marginBottom: 8 }}>
      <div className="row-between" style={{ marginBottom: 6 }}>
        <div>
          <div style={{ fontWeight: 500, fontSize: 14 }}>{session.programName} — {session.dayName}</div>
          <div style={{ fontSize: 12, color: 'var(--text2)' }}>{formatDate(session.date)} · {Math.round((session.duration||0)/60000)}min · {doneSets} séries</div>
        </div>
        <div style={{ fontSize: 13, color: 'var(--accent)', fontWeight: 600 }}>
          {Math.round(sessionVolume(session) / 100) / 10}k kg
        </div>
      </div>
      <div className="tags">
        {muscles.slice(0,4).map(m => (
          <span key={m} className="badge" style={{ background: `${MUSCLE_COLORS[m]}22`, color: MUSCLE_COLORS[m] || 'var(--text2)', fontSize: 10 }}>{m}</span>
        ))}
      </div>
    </div>
  )
}
