import { useState, useEffect, useRef, useCallback } from 'react'
import { useApp } from '../store/AppContext'
import { uid, formatDuration, MUSCLE_COLORS, playBeep, vibrate } from '../utils/helpers'
import { Check, X, ChevronUp, ChevronDown, StopCircle, Clock } from 'lucide-react'

export default function Workout({ onNavigate }) {
  const { activeSession, setActiveSession, finishSession } = useApp()
  const [session, setSession] = useState(activeSession)
  const [timerActive, setTimerActive] = useState(false)
  const [timerLeft, setTimerLeft] = useState(0)
  const [timerTotal, setTimerTotal] = useState(session?.restSeconds || 90)
  const [elapsed, setElapsed] = useState(0)
  const timerRef = useRef(null)
  const elapsedRef = useRef(null)
  const startTime = useRef(session?.startTime || Date.now())

  // Elapsed workout time
  useEffect(() => {
    elapsedRef.current = setInterval(() => {
      setElapsed(Math.floor((Date.now() - startTime.current) / 1000))
    }, 1000)
    return () => clearInterval(elapsedRef.current)
  }, [])

  // Rest timer
  useEffect(() => {
    if (timerActive) {
      timerRef.current = setInterval(() => {
        setTimerLeft(prev => {
          if (prev <= 1) {
            clearInterval(timerRef.current)
            setTimerActive(false)
            playBeep()
            vibrate([300, 100, 300, 100, 300])
            // Notification
            if (Notification.permission === 'granted') {
              new Notification('AbbaFit', { body: 'Tempo de descanso acabou! Próxima série.' })
            }
            return 0
          }
          return prev - 1
        })
      }, 1000)
    } else {
      clearInterval(timerRef.current)
    }
    return () => clearInterval(timerRef.current)
  }, [timerActive])

  function startRest() {
    setTimerLeft(timerTotal)
    setTimerActive(true)
    if (Notification.permission === 'default') Notification.requestPermission()
  }

  function stopRest() {
    setTimerActive(false)
    setTimerLeft(0)
  }

  function toggleSet(exIdx, setIdx) {
    setSession(prev => {
      const next = JSON.parse(JSON.stringify(prev))
      const set = next.exercises[exIdx].sets[setIdx]
      set.done = !set.done
      // Auto-start rest timer when marking done
      if (set.done) {
        startRest()
      }
      return next
    })
  }

  function updateSet(exIdx, setIdx, field, value) {
    setSession(prev => {
      const next = JSON.parse(JSON.stringify(prev))
      next.exercises[exIdx].sets[setIdx][field] = value
      return next
    })
  }

  const totalSets = session?.exercises?.reduce((a, ex) => a + (ex.sets?.length || 0), 0) || 0
  const doneSets = session?.exercises?.reduce((a, ex) => a + (ex.sets?.filter(s => s.done).length || 0), 0) || 0
  const progress = totalSets ? doneSets / totalSets : 0

  async function finish() {
    if (!confirm('Finalizar treino?')) return
    const final = {
      ...session,
      duration: Date.now() - startTime.current,
      exercises: session.exercises
    }
    await finishSession(final)
    onNavigate('home')
  }

  if (!session) {
    return (
      <div className="page" style={{ textAlign: 'center', paddingTop: 60 }}>
        <p style={{ color: 'var(--text2)', marginBottom: 20 }}>Nenhum treino ativo</p>
        <button className="btn btn-primary" onClick={() => onNavigate('programs')}>Ver Programas</button>
      </div>
    )
  }

  const ringR = 44
  const ringCirc = 2 * Math.PI * ringR
  const ringOffset = timerActive ? ringCirc * (1 - timerLeft / timerTotal) : ringCirc

  return (
    <div className="page page-enter" style={{ paddingBottom: 100 }}>
      {/* Header */}
      <div style={{ marginBottom: 20 }}>
        <div className="label" style={{ marginBottom: 2 }}>{session.programName}</div>
        <h1 className="display" style={{ fontSize: 28 }}>{session.dayName}</h1>
        <div className="row" style={{ marginTop: 6, gap: 12 }}>
          <span style={{ fontSize: 13, color: 'var(--text2)' }}>
            <Clock size={12} style={{ display:'inline', verticalAlign:'middle', marginRight: 4 }}/>
            {formatDuration(elapsed)}
          </span>
          <span style={{ fontSize: 13, color: 'var(--text2)' }}>{doneSets}/{totalSets} séries</span>
        </div>
        {/* Progress bar */}
        <div style={{ height: 4, background: 'var(--border)', borderRadius: 2, marginTop: 10 }}>
          <div style={{ height: '100%', background: 'var(--accent)', borderRadius: 2, width: `${progress*100}%`, transition: 'width 0.3s' }}/>
        </div>
      </div>

      {/* Rest Timer */}
      <div className="card" style={{ display: 'flex', alignItems: 'center', gap: 16, padding: 16, marginBottom: 16 }}>
        {/* Ring */}
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <svg width={100} height={100} style={{ transform: 'rotate(-90deg)' }}>
            <circle cx={50} cy={50} r={ringR} fill="none" stroke="var(--border)" strokeWidth={6}/>
            <circle
              cx={50} cy={50} r={ringR} fill="none"
              stroke={timerActive ? 'var(--accent)' : timerLeft === 0 && !timerActive && doneSets > 0 ? '#2d2d2d' : 'var(--border2)'}
              strokeWidth={6}
              strokeDasharray={ringCirc}
              strokeDashoffset={timerActive ? ringCirc * (1 - timerLeft / timerTotal) : timerLeft > 0 ? ringCirc * (1 - timerLeft / timerTotal) : ringCirc}
              strokeLinecap="round"
              style={{ transition: timerActive ? 'stroke-dashoffset 1s linear' : 'none' }}
            />
          </svg>
          <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column' }}>
            <div className="display" style={{ fontSize: 22, lineHeight: 1 }}>
              {timerActive ? formatDuration(timerLeft) : '—'}
            </div>
            {timerActive && <div style={{ fontSize: 9, color: 'var(--text2)', marginTop: 2 }}>restante</div>}
          </div>
        </div>

        <div style={{ flex: 1 }}>
          <div className="label" style={{ marginBottom: 6 }}>Descanso</div>
          <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 8 }}>
            <button className="btn-icon" onClick={() => setTimerTotal(t => Math.max(10, t-15))}><ChevronDown size={14}/></button>
            <span style={{ fontWeight: 600, minWidth: 40, textAlign: 'center' }}>{timerTotal}s</span>
            <button className="btn-icon" onClick={() => setTimerTotal(t => t+15)}><ChevronUp size={14}/></button>
          </div>
          {timerActive
            ? <button className="btn btn-danger btn-sm btn-full" onClick={stopRest}><X size={13}/> Parar</button>
            : <button className="btn btn-ghost btn-sm btn-full" onClick={startRest}><Clock size={13}/> Iniciar timer</button>
          }
        </div>
      </div>

      {/* Exercises */}
      {session.exercises?.map((ex, exIdx) => {
        const allDone = ex.sets?.every(s => s.done)
        return (
          <div key={ex.id} className="card" style={{ marginBottom: 12, opacity: allDone ? 0.75 : 1 }}>
            <div className="row-between" style={{ marginBottom: 12 }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                <div style={{ width: 10, height: 10, borderRadius: '50%', background: MUSCLE_COLORS[ex.muscle] || '#555', flexShrink: 0 }}/>
                <div>
                  <div style={{ fontWeight: 600, fontSize: 15 }}>{ex.name}</div>
                  <div style={{ fontSize: 12, color: 'var(--text2)' }}>{ex.muscle}</div>
                </div>
              </div>
              {allDone && <span className="badge badge-accent">✓ Feito</span>}
            </div>

            {/* Set table header */}
            <div style={{ display: 'grid', gridTemplateColumns: '28px 1fr 1fr 40px', gap: 6, marginBottom: 6, padding: '0 4px' }}>
              <span style={{ fontSize: 10, color: 'var(--text3)' }}>#</span>
              <span style={{ fontSize: 10, color: 'var(--text3)' }}>Reps</span>
              <span style={{ fontSize: 10, color: 'var(--text3)' }}>Kg</span>
              <span/>
            </div>

            {ex.sets?.map((set, setIdx) => (
              <div key={set.id} style={{
                display: 'grid', gridTemplateColumns: '28px 1fr 1fr 40px',
                gap: 6, alignItems: 'center', marginBottom: 8,
                padding: '6px', borderRadius: 8,
                background: set.done ? 'var(--accent-dim)' : 'transparent',
                transition: 'background 0.2s'
              }}>
                <span style={{ fontSize: 12, color: set.done ? 'var(--accent)' : 'var(--text3)', textAlign: 'center', fontWeight: 600 }}>{setIdx+1}</span>
                <input
                  type="number" inputMode="numeric"
                  value={set.actualReps ?? set.reps}
                  onChange={e => updateSet(exIdx, setIdx, 'actualReps', +e.target.value)}
                  style={{ fontSize: 15, fontWeight: 600, padding: '8px', textAlign: 'center', border: set.done ? '1px solid var(--accent)' : undefined }}
                  min={0}
                />
                <input
                  type="number" inputMode="decimal"
                  value={set.actualWeight ?? set.weight}
                  onChange={e => updateSet(exIdx, setIdx, 'actualWeight', +e.target.value)}
                  style={{ fontSize: 15, fontWeight: 600, padding: '8px', textAlign: 'center', border: set.done ? '1px solid var(--accent)' : undefined }}
                  min={0} step={0.5}
                />
                <button
                  onClick={() => toggleSet(exIdx, setIdx)}
                  style={{
                    width: 36, height: 36, borderRadius: '50%', border: 'none',
                    background: set.done ? 'var(--accent)' : 'var(--bg3)',
                    color: set.done ? '#0a0a0a' : 'var(--text2)',
                    cursor: 'pointer', display: 'flex', alignItems: 'center', justifyContent: 'center',
                    transition: 'all 0.15s', transform: set.done ? 'scale(1.1)' : 'scale(1)'
                  }}
                >
                  <Check size={16}/>
                </button>
              </div>
            ))}

            {ex.obs && <div style={{ fontSize: 12, color: 'var(--text2)', marginTop: 4, fontStyle: 'italic' }}>{ex.obs}</div>}
          </div>
        )
      })}

      {/* Finish button */}
      <button
        className="btn btn-primary btn-full"
        style={{ marginTop: 8, padding: 16, fontSize: 16 }}
        onClick={finish}
      >
        <StopCircle size={18}/> Finalizar treino
      </button>
    </div>
  )
}
