import { createContext, useContext, useState, useEffect, useCallback } from 'react'
import * as db from './db'

const AppContext = createContext(null)

export function AppProvider({ children }) {
  const [programs, setPrograms] = useState([])
  const [sessions, setSessions] = useState([])
  const [measurements, setMeasurements] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeSession, setActiveSession] = useState(null) // live workout

  const reload = useCallback(async () => {
    const [p, s, m] = await Promise.all([
      db.getPrograms(),
      db.getSessions(),
      db.getMeasurements()
    ])
    setPrograms(p)
    setSessions(s.sort((a, b) => b.date - a.date))
    setMeasurements(m.sort((a, b) => b.date - a.date))
    setLoading(false)
  }, [])

  useEffect(() => { reload() }, [reload])

  const saveProgram = async (program) => {
    await db.saveProgram(program)
    await reload()
  }
  const deleteProgram = async (id) => {
    await db.deleteProgram(id)
    await reload()
  }
  const finishSession = async (session) => {
    await db.saveSession(session)
    setActiveSession(null)
    await reload()
  }
  const saveMeasurement = async (m) => {
    await db.saveMeasurement(m)
    await reload()
  }
  const deleteMeasurement = async (id) => {
    await db.deleteMeasurement(id)
    await reload()
  }

  return (
    <AppContext.Provider value={{
      programs, sessions, measurements, loading,
      activeSession, setActiveSession,
      saveProgram, deleteProgram,
      finishSession, saveMeasurement, deleteMeasurement,
      reload
    }}>
      {children}
    </AppContext.Provider>
  )
}

export const useApp = () => useContext(AppContext)
