import { openDB } from 'idb'

const DB_NAME = 'abbafit'
const DB_VERSION = 1

export async function getDB() {
  return openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains('programs')) {
        db.createObjectStore('programs', { keyPath: 'id' })
      }
      if (!db.objectStoreNames.contains('sessions')) {
        const s = db.createObjectStore('sessions', { keyPath: 'id' })
        s.createIndex('date', 'date')
        s.createIndex('programId', 'programId')
      }
      if (!db.objectStoreNames.contains('measurements')) {
        const m = db.createObjectStore('measurements', { keyPath: 'id' })
        m.createIndex('date', 'date')
      }
      if (!db.objectStoreNames.contains('settings')) {
        db.createObjectStore('settings', { keyPath: 'key' })
      }
    }
  })
}

// Programs
export async function saveProgram(program) {
  const db = await getDB()
  await db.put('programs', program)
}
export async function getPrograms() {
  const db = await getDB()
  return db.getAll('programs')
}
export async function getProgram(id) {
  const db = await getDB()
  return db.get('programs', id)
}
export async function deleteProgram(id) {
  const db = await getDB()
  await db.delete('programs', id)
}

// Sessions (completed workouts)
export async function saveSession(session) {
  const db = await getDB()
  await db.put('sessions', session)
}
export async function getSessions() {
  const db = await getDB()
  return db.getAll('sessions')
}
export async function getSessionsByProgram(programId) {
  const db = await getDB()
  return db.getAllFromIndex('sessions', 'programId', programId)
}

// Measurements
export async function saveMeasurement(m) {
  const db = await getDB()
  await db.put('measurements', m)
}
export async function getMeasurements() {
  const db = await getDB()
  return db.getAll('measurements')
}
export async function deleteMeasurement(id) {
  const db = await getDB()
  await db.delete('measurements', id)
}

// Settings
export async function getSetting(key, defaultVal) {
  const db = await getDB()
  const r = await db.get('settings', key)
  return r ? r.value : defaultVal
}
export async function setSetting(key, value) {
  const db = await getDB()
  await db.put('settings', { key, value })
}
