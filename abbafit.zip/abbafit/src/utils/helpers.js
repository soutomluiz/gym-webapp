export const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36)

export const MUSCLE_GROUPS = [
  'Peito', 'Costas', 'Ombro', 'Bíceps', 'Tríceps',
  'Antebraço', 'Core / Abdômen', 'Glúteo', 'Quadríceps',
  'Posterior', 'Panturrilha', 'Trapézio', 'Deltóide posterior', 'Full Body'
]

export const WORKOUT_TYPES = [
  'Push', 'Pull', 'Legs', 'PPL', 'Upper/Lower',
  'Full Body', 'Força', 'Hipertrofia', 'Funcional', 'Cardio', 'Outro'
]

export const MUSCLE_COLORS = {
  'Peito': '#e85d04',
  'Costas': '#0077b6',
  'Ombro': '#7b2d8b',
  'Bíceps': '#2d6a4f',
  'Tríceps': '#1b4332',
  'Antebraço': '#40916c',
  'Core / Abdômen': '#d62828',
  'Glúteo': '#f77f00',
  'Quadríceps': '#fcbf49',
  'Posterior': '#4361ee',
  'Panturrilha': '#3a86ff',
  'Trapézio': '#8338ec',
  'Deltóide posterior': '#c77dff',
  'Full Body': '#adb5bd'
}

export function formatDate(ts) {
  return new Date(ts).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' })
}

export function formatDuration(seconds) {
  const m = Math.floor(seconds / 60)
  const s = seconds % 60
  return `${m}:${String(s).padStart(2, '0')}`
}

export function weekLabel(ts) {
  const d = new Date(ts)
  const start = new Date(d)
  start.setDate(d.getDate() - d.getDay())
  return `${start.getDate()}/${start.getMonth() + 1}`
}

export function monthLabel(ts) {
  return new Date(ts).toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' })
}

// Group sessions by week
export function groupByWeek(sessions) {
  const map = {}
  sessions.forEach(s => {
    const key = weekLabel(s.date)
    if (!map[key]) map[key] = []
    map[key].push(s)
  })
  return map
}

// Group sessions by month
export function groupByMonth(sessions) {
  const map = {}
  sessions.forEach(s => {
    const key = monthLabel(s.date)
    if (!map[key]) map[key] = []
    map[key].push(s)
  })
  return map
}

// Total volume (sets × reps × weight) from a session
export function sessionVolume(session) {
  let v = 0
  session.exercises?.forEach(ex => {
    ex.sets?.forEach(set => {
      if (set.done) v += (set.reps || 0) * (set.weight || 0)
    })
  })
  return v
}

// All exercises done grouped by muscle
export function volumeByMuscle(sessions) {
  const map = {}
  sessions.forEach(s => {
    s.exercises?.forEach(ex => {
      const m = ex.muscle || 'Full Body'
      if (!map[m]) map[m] = 0
      ex.sets?.forEach(set => {
        if (set.done) map[m] += (set.reps || 0) * (set.weight || 0)
      })
    })
  })
  return map
}

export function playBeep() {
  try {
    const ctx = new (window.AudioContext || window.webkitAudioContext)()
    const osc = ctx.createOscillator()
    const gain = ctx.createGain()
    osc.connect(gain)
    gain.connect(ctx.destination)
    osc.frequency.value = 880
    osc.type = 'sine'
    gain.gain.setValueAtTime(0.6, ctx.currentTime)
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.8)
    osc.start(ctx.currentTime)
    osc.stop(ctx.currentTime + 0.8)
  } catch (e) {}
}

export function vibrate(pattern = [200, 100, 200]) {
  if (navigator.vibrate) navigator.vibrate(pattern)
}
